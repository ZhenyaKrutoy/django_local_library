from django.shortcuts import render

def base(request):
    return render(request, 'base_layout.html')

def page1(request):
    return render(request, 'page_1.html')

def page2(request):
    return render(request, 'page_2.html')

def page3(request):
    return render(request, 'page_3.html')



