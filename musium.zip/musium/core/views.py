from django.shortcuts import render

def base_view(request):
    return render(request, 'base_layout.html')

def page1_view(request):
    return render(request, 'page_1.html')

def page2_view(request):
    return render(request, 'page_2.html')

def page3_view(request):
    return render(request, 'page_3.html')



