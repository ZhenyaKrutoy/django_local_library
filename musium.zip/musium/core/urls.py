from django.urls import path
from .views import *

musium_urlpatterns = [
    path('page_1/', page1_view , name = 'page_1.html'),
    path('page_2/', page2_view, name = 'page_2.html'),
    path('page_3/', page3_view, name = 'page_3.html'),
]

base_urlpatterns = [
    path('', base_view, name='base_layout.html'), 
]
