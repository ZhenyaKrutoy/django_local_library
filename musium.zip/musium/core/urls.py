from django.urls import path
from . import views

musium_urlpatterns = [
    path('page_1/', views.page1, name = 'page_1'),
    path('page_2/', views.page2, name = 'page_2'),
    path('page_3/', views.page3, name = 'page_3'),
]

base_urlpatterns = [
    path('',  views.base, name='base_layout'), 
]
