from django.contrib import admin
from django.urls import path, include
import core.urls as core_urls
from django.conf.urls.static import static
from app.settings import MEDIA_ROOT, MEDIA_URL


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(core_urls.musium_urlpatterns)),
    path('',include(core_urls.base_urlpatterns)),
]

urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)